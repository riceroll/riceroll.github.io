### Build
1. **Install Docker:**  
Follow the instructions on [Docker's installation page](https://docs.docker.com/engine/install/).

2. **Build the Image:**  
Run the following command from the project root:
```bash
docker build -t pneumeshplus . --cache-from pneumeshplus:latest
```
*Note:* The `--cache-from` flag reuses cached layers from the latest image only when available.

---

### Train
Replace `[Example]` with the desired example name from the `scripts` folder. Available examples include:  
`Lobster`, `Helmet`, `Pillbug`, `Tentacle`, `Quadruped_2`, `Quadruped_4`, `Quadruped_8`, `Quadruped_16`, `Quadruped_32`, and `Quadruped_64`.

Run the training script with:
```bash
docker run -it -v $(pwd)/scripts/[Example]:/home/scripts/[Example] pneumeshplus python ./scripts/[Example]/train.py
```

- **Multi-Core Processing:**  
  The experiments are parallelized by default and are designed for a 64-core machine.
  
- **Output Files:**  
  All output files are saved in the checkpoint folder at `./scripts/[Example]/output/checkpoints_[beginning_time]`.

- **Training Log:**  
  The training log is printed to the console and saved as `./scripts/[Example]/output/log.txt`. It includes the multi-objective performance (fitness) of the elite designs (indexed by generation).

---

### Save the Training History Plot
To generate and save a plot of the training history (regardless of whether training is still running), execute:
```bash
docker run -it -v $(pwd)/scripts/[Example]:/home/scripts/[Example] pneumeshplus python ./scripts/plotTrainingPerformance.py [CheckPointsFolder]
```
Replace `[CheckPointsFolder]` with the relative path to the checkpoint folder you wish to plot. The plot will be saved in:
```
./scripts/[Example]/output/checkpoints_[beginning_time]/plots/
```

---

## Simulate Training Results
Since running a GUI in Docker is complex, you must save the simulation trajectory using Docker and then visualize it locally with matplotlib.

### Save Simulation Trajectory
1. **Select a Design:**  
   From the training log, note the generation index and design index of the design you wish to simulate.

2. **Run the Command:**  
   Replace `[CheckPointsFolder]`, `[GenerationIndex]`, and `[DesignIndex]` with the appropriate values:
   ```bash
   docker run -it -v $(pwd)/scripts/[Example]:/home/scripts/[Example] pneumeshplus python ./scripts/saveSimulation.py [CheckPointsFolder] [GenerationIndex] [DesignIndex]
   ```
   The simulation file will be named:
   ```
   generation_[GenerationIndex]_gene_[DesignIndex].simulation.npy
   ```
   and saved in:
   ```
   ./scripts/[Example]/output/checkpoints_[beginning_time]/simulations/
   ```

---

### Set Up Your Local Environment for Simulation
Install Python (if not already installed) and the required packages:
```bash
pip install numpy matplotlib
```

### Run the Simulation Animation
To animate the simulation trajectory, run:
```bash
python ./scripts/animateSimulation.py [simulationFileName]
```
Replace `[simulationFileName]` with the name of the simulation file you want to visualize. The GUI will display the trajectories sequentially after each window is closed.
