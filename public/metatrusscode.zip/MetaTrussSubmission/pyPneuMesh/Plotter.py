import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import matplotlib.ticker as ticker
import seaborn as sns
import tqdm

class Plotter:
    def __init__(self, width=3, height=2, fontSize=7):
        
        self.fontSize = fontSize
        
        self.curveWidth = 0.5
        self.shadeAlpha = 0.1
        
        self.tickLength = 1.0
        self.tickWidth = 0.5
        
        sns.set_theme(style="white")
        plt.rc('font', family='Arial')
        
        # prev colors
        self.colors = [
            '#F21365',
            '#48C288',
            '#F1B807',
            '#63A5BF',
            '#F27A5E',
            '#F5AB55',
        ]
        
        
        # self.colors = [
        #     '#F36C46',
        #     '#63A5BF',
        #     '#F6D359',
        #     '#E33247',
        #     '#F59B43',
        #     '#66C8D2'
        # ]
        
        dpi = 72 * 10
        plt.figure(figsize=(width, height), dpi=dpi)
        

    
    def plotCurve(self, x, Y, label="Label", colorIndex=0, monotonic=False):
        # x: values for x axis [nx, ]
        # Y: values for y axis [nSamples, nY]
        
        # preprocessing data
        assert(x.ndim == 1 and Y.ndim == 2)
        nSamples = Y.shape[0]       # if nSamples is 1, no std plotted, others std plotted
        
        if nSamples == 1:   # no std, directly plot Y
            y = Y.reshape(-1)
        else:   # plot mean and std
            y = Y.mean(0)
        
        # filter non-monotonic values
        if monotonic:
            for i in range(1, len(y)):
                if y[i] < y[i-1]:
                    y[i] = y[i-1]
        

        # plot
        plt.plot(x, y, color=self.colors[colorIndex], label=label, lw=self.curveWidth)
        
        # plot shade
        if nSamples > 1:
            std = Y.std(0)

            lower = y - std
            upper = y + std
            plt.fill_between(x, lower, upper, color=self.colors[colorIndex], alpha=self.shadeAlpha)
    
    def plotContractionDesign(self, contractionLevel):
        indices = np.arange(len(contractionLevel))
        plt.bar(indices, contractionLevel, width=1, linewidth=0.5)
    
    def plotChannelDesign(self, edgeChannel):
        indices = np.arange(len(edgeChannel))
        cs = [self.colors[value] for value in edgeChannel]
        plt.bar(indices, 1.0, bottom=edgeChannel, width=1, color=cs, linewidth=0.7)
    
    def scatterAndText(self, labels, X, Y):
        # scatter
        plt.scatter(X, Y)
        
        # text
        for i, label in enumerate(labels):
            plt.text(X[i] - 5, Y[i] + 0.2, label)
        
    def plot5bars(self, X, width=0.2, alpha=1):
        plt.bar([0, 1, 2, 3, 4], X, color=self.colors[:5], width=width, alpha=alpha )
        
        
    def show(self, title=None, xLabel=None, yLabel=None,
             folderDir='', save=False,
             legend=True, xLog=False, yLog=False, fullFrame=False,
             xTicks=None, yTicks=None, xFormatterFunc=None, yFormatterFunc=None,
             pad=0.5 ):
    
        # appearance
        plt.tick_params(left="on", bottom="on", direction="in", length=self.tickLength, width=self.tickWidth, labelsize=self.fontSize)
        
        # Change the frame width
        ax = plt.gca()  # Get the current axes
        if fullFrame:
            frameWidths = [0.5, 0.5, 0.5, 0.5]
        else:
            frameWidths = [0.5, 0.5, 0, 0]
            
        for i, axis in enumerate(['left', 'bottom', 'right', 'top']):
            ax.spines[axis].set_linewidth(frameWidths[i])
        

        if xLog:
            plt.xscale('log')


        # yLog
        if yLog:
            plt.yscale('log')
        
        # legend
        if legend:
            plt.legend(frameon=False, fontsize=self.fontSize)
        
        # xTicks and yTicks:
        if xTicks:
            plt.xticks(xTicks[0], xTicks[1])
        
        if yTicks:
            plt.yticks(yTicks[0], yTicks[1])
            # plt.yticks(y_locs, [f'{loc:.3f}' for loc in y_locs])
        
        
        if xFormatterFunc:
            xFormatter = ticker.FuncFormatter(xFormatterFunc)
            plt.gca().xaxis.set_major_formatter(xFormatter)
        
        if yFormatterFunc:
            yFormatter = ticker.FuncFormatter(yFormatterFunc)
            plt.gca().yaxis.set_major_formatter(yFormatter)
        
        
        
        # title and labels
        if title and False: # don't plot title, do it in Figma
            plt.title(title, fontsize=self.fontSize)
        if xLabel:
            plt.xlabel(xLabel, fontsize=self.fontSize)
        if yLabel:
            plt.ylabel(yLabel, fontsize=self.fontSize)
        
        
        # layout
        plt.tight_layout(pad=pad)
        
        # save
        if save:
            if folderDir[-1] != '/':
                folderDir += '/'
            fileDir = folderDir + title
            plt.savefig(fileDir)
            print('saved to {}'.format(fileDir))
        
        plt.show()
        

    