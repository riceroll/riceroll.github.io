import os
import sys

# Get the directory of the script
script_dir = os.path.dirname(__file__)
grand_grand_parent_dir = os.path.dirname(os.path.dirname(script_dir))
sys.path.append(grand_grand_parent_dir)

from pyPneuMesh.utils import plotPerformance

plotPerformance(sys.argv[1])


