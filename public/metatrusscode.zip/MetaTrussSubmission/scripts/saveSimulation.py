import os
import numpy as np
import sys

# Get the directory of the script
script_dir = os.path.dirname(__file__)
parent_dir = os.path.dirname(script_dir)
sys.path.append(parent_dir)

print(parent_dir)

from pyPneuMesh.utils import readNpy
from pyPneuMesh.MOO import MOO

checkpointsDir = sys.argv[1]
iGeneration = int(sys.argv[2])
iGene = int(sys.argv[3])

checkpointDir = os.path.join(checkpointsDir, 'ElitePool_{:d}.gacheckpoint.npy'.format(iGeneration))


# fileName
ga = readNpy(checkpointDir)
mooDict = ga['elitePoolMOODict'][iGene]['mooDict']
moo = MOO(mooDict=mooDict)

numActions = len(moo.multiMotion.actionSeqs)

data = {
    'e': moo.model.e,
    'edgeChannel': moo.model.edgeChannel,
    'VTrajectories': [],
}

print('loaded')

for iAction in range(numActions):
    Vs, Fs = moo.multiMotion.simulate(iAction, numLoop=4)
    data['VTrajectories'].append(Vs)

print('simulated')

simulationDir = os.path.join(checkpointsDir, 'simulations', 'generation_{:d}_gene_{:d}.simulation.npy'.format(iGeneration, iGene))
# create if not exist
if not os.path.exists(os.path.dirname(simulationDir)):
    os.makedirs(os.path.dirname(simulationDir))

print('saving')

np.save(simulationDir, data)

print('saved')











