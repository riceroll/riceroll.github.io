import os
import numpy as np
import sys

# Get the directory of the script
script_dir = os.path.dirname(__file__)
grand_grand_parent_dir = os.path.dirname(os.path.dirname(script_dir))
sys.path.append(grand_grand_parent_dir)

fileDir = sys.argv[1]

data = np.load(fileDir, allow_pickle=True).all()

e = data['e']
edgeChannel = data['edgeChannel']
VTrajectories = data['VTrajectories']


for Vs in VTrajectories:
    
    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d import Axes3D
    from mpl_toolkits.mplot3d.art3d import Line3DCollection
    import matplotlib.animation as animation
    import matplotlib.colors as mcolors
    import time
    
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    plt.subplots_adjust(left=0.01, right=0.99, bottom=0.01, top=0.99, wspace=0.1, hspace=0.1)
    
    ax.w_xaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
    ax.w_yaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
    
    # turn off z-axis
    ax.set_zticks([])
    ax.set_zlabel('')
    ax.set_zticklabels([])
    
    
    # Define a list of colors
    color_list = ['red', 'green', 'blue', 'orange', 'purple', 'cyan', 'magenta', 'lime', 'navy', 'teal']
    
    start_time = time.time()
    
    # Set the camera position and orientation
    elevation = 30  # Elevation angle in degrees
    azimuth = -60   # Azimuth angle in degrees
    ax.view_init(elev=elevation, azim=azimuth)
    
    
    # Set the fixed range for the bottom grid
    x_range = (-2, 2)  # Adjust the range as needed
    y_range = (-2, 2)  # Adjust the range as needed
    z_range = (0, 2)  # Adjust the range as needed
    
    
    def update(frame):
        ax.clear()
    
        elapsed_time = time.time() - start_time
        fps = 3000
        # Calculate the current frame based on elapsed time and desired FPS
        current_frame = int(elapsed_time * fps)
        
        if current_frame >= len(Vs):
            current_frame = len(Vs) - 1
        
        # Get the vertex positions for the current frame
        V = Vs[current_frame]
        
        # Create a list to store the line segments and colors
        lines = []
        colors = []
        
        for i in range(len(e)):
            start = tuple(V[e[i, 0]])
            end = tuple(V[e[i, 1]])
            lines.append([start, end])
            color_index = edgeChannel[i]
            colors.append(color_list[color_index])
        
        # Create a Line3DCollection with the line segments and colors
        line_segments = Line3DCollection(lines, colors=colors, linewidths=2)
        
        # Add the Line3DCollection to the plot
        ax.add_collection(line_segments)
        
        ax.set_xlim(x_range)
        ax.set_ylim(y_range)
        ax.set_zlim(z_range)
        
        # Set the limits of the plot based on the vertex positions
        
        # Set the fixed range for the bottom grid
        
        # ax.set_zlim(0, max(x_range[1], y_range[1]))  # Adjust the z-limit based on the maximum of x and y ranges
        
        
        # Set labels for the axes
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        # ax.set_zlabel('Z')
        
        ax.set_box_aspect((1, 1, 0.5))
        
        # ax.set_aspect('equal')
        
        ax.grid(False)
        
    
    # Create the animation
    ani = animation.FuncAnimation(fig, update, frames=len(Vs), interval=1)
    
    # Display the animation
    plt.show()