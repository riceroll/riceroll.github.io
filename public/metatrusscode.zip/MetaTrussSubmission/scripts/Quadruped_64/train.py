import numpy as np
import json
import multiprocessing

import os
import sys

# Get the directory of the script
script_dir = os.path.dirname(__file__)

grand_grand_parent_dir = os.path.dirname(os.path.dirname(script_dir))

sys.path.append(grand_grand_parent_dir)


from pyPneuMesh.utils import readNpy, readMooDict
from pyPneuMesh.Model import Model
from pyPneuMesh.Graph import Graph
from pyPneuMesh.MOO import MOO
from pyPneuMesh.GA import GA


GASetting = {
    'nGenesPerPool': 1024,
    'nSurvivedMin': 512,
    
    
    'nGensPerPool': 8,

    'nWorkers': multiprocessing.cpu_count(),

    'folderDir': 'scripts/Quadruped_64/',
    
    'graphRandomInit': True,
    'contractionActionRandomInit': True,
    
    'contractionMutationChance': 0.01,
    'actionMutationChance': 0.01,
    'graphMutationChance': 0.1,
    'contractionCrossChance': 0.02,
    'actionCrossChance': 0.02,
    'crossChance': 0.5,

}
ga = GA(GASetting=GASetting)
ga.run()
