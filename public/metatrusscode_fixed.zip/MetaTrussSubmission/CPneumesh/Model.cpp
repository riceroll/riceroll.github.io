#include "Model.h"
#include "pybind11/pybind11.h"

using namespace std;
using namespace Eigen;
namespace py = pybind11;

Model::Model(VectorXd K, double h, double gravity, double damping, double friction,
             MatrixXd v0, MatrixXi e, double CONTRACTION_SPEED, VectorXi fixed)
   {

  this->V0 = v0;
  this->V = v0;
  this->E = e;
  this->fixed = fixed;

  Vel.resize(V0.rows(), 3);
  Vel.setZero();
  Force.resize(V0.rows(), 3);

  this->h = h;
  this->K = K;
  this->gravity = gravity;
  this->damping = damping;
  this->friction = friction;
  this->CONTRACTION_SPEED = CONTRACTION_SPEED;

  this->L0 = getL(V0, E);
}

VectorXd Model::getL(MatrixXd V, MatrixXi E) {
  auto vec = V(E(all, 0), all) - V(E(all, 1), all);
  auto L = vec.rowwise().norm();
  return L;
}

MatrixXi Model::getE() {
  return this->E;
}

std::pair<VectorXd, VectorXd> Model::step(VectorXd times, MatrixXd lengths, int numSteps) {
  MatrixXd V = V0;

  VectorXd LTarget = lengths.row(0);   // target length of pneumatic actuation

  VectorXd Fs((numSteps + 1) * E.rows() * 1);

  VectorXd Vs((numSteps + 1) * V.rows() * 3);
  for (int iRow = 0; iRow < V.rows(); iRow++) {
    for (int iCol=0; iCol < V.cols(); iCol++) {
      Vs((0 * V.rows() + iRow) * 3 + iCol) = V(iRow, iCol);
    }
  }

  for (int iStep=0; iStep < numSteps; iStep++) {
    Force.setZero();

    double time = h * iStep;

    // set LTarget
    for (int iTime = 0; iTime < times.size(); iTime++) {
      if (time > times[iTime]) {
        LTarget = lengths.row(iTime);
      }
    }

    // set L0
    for (int iE = 0; iE < E.rows(); iE++) {
      if (L0[iE] != LTarget[iE]) {
        double diff = LTarget[iE] - L0[iE];
        double sign = diff / abs(diff);
        double dL0 = sign * CONTRACTION_SPEED * h;
        if (abs(dL0) > abs(diff)) {   // L0 goes over LTarget
          L0[iE] = LTarget[iE];
        } else {
          L0[iE] += dL0;
        }
      }
    }

    // calculate edge force
    VectorXd FEdge;
    FEdge.resize(E.size());
    auto L = getL(V, E);
    auto Vec01 = V(E(all, 1), all) - V(E(all, 0), all); // vectors from V[e[0]] to V[e[1]]

    for (int iE = 0; iE < E.rows(); iE++) {
      FEdge[iE] = (L[iE] - L0[iE]) * K[iE];   // contraction force is positive

      Force.row(E(iE, 0)) += Vec01.row(iE) / L[iE] * FEdge[iE];
      Force.row(E(iE, 1)) -= Vec01.row(iE) / L[iE] * FEdge[iE];
    }

    Force(all, 2).array() -= gravity;

    // contact with ground
    for (int iV = 0; iV < V.rows(); iV++) {

      // support and friction
      if (V(iV, 2) < 0 and Force(iV, 2) < 0) {
        double forceSupport = -Force(iV, 2);
        Force(iV, 2) = 0;

        double fFrictionMaxMag = forceSupport * friction;
        VectorXd velHorizontal(3);
        velHorizontal << Vel(iV, 0), Vel(iV, 1), 0;

        if (fFrictionMaxMag * h > velHorizontal.norm()) {
          fFrictionMaxMag = velHorizontal.norm() / h;
        }

        Force.row(iV) += -fFrictionMaxMag * velHorizontal / velHorizontal.norm();
      }

      // velocity on ground
      if (V(iV, 2) < 0 and Vel(iV, 2) < 0) {
        Vel(iV, 2) = 0;
        V(iV, 2) = 0;
      }
    }

    Vel = Vel + Force * h;
    Vel = Vel * damping;

    V += Vel * h;

    for (int i=0; i<V.rows(); i++) {
        if (fixed[i] == 1) {
            V.row(i) -= Vel.row(i) * h;
        }
    }

    for (int iRow = 0; iRow < V.rows(); iRow++) {
      for (int iCol=0; iCol < V.cols(); iCol++) {
        Vs(( (iStep + 1) * V.rows() + iRow) * 3 + iCol) = V(iRow, iCol);
      }
    }

    for (int iE = 0; iE < E.rows(); iE++) {
        Fs[iStep * E.rows() + iE] = FEdge[iE];
    }
  }

  return std::make_pair(Vs, Fs);
}

MatrixXd Model::stepForGym(VectorXd lengths, int numSteps) {
  VectorXd LTarget = lengths;   // target length of pneumatic actuation

  for (int iStep=0; iStep < numSteps; iStep++) {
    Force.setZero();

    // set L0
    for (int iE = 0; iE < E.rows(); iE++) {
      if (L0[iE] != LTarget[iE]) {
        double diff = LTarget[iE] - L0[iE];
        double sign = diff / abs(diff);
        double dL0 = sign * CONTRACTION_SPEED * h;
        if (abs(dL0) > abs(diff)) {   // L0 goes over LTarget
          L0[iE] = LTarget[iE];
        } else {
          L0[iE] += dL0;
        }
      }
    }

    // calculate edge force
    VectorXd FEdge;
    FEdge.resize(E.size());
    auto L = getL(V, E);
    auto Vec01 = V(E(all, 1), all) - V(E(all, 0), all); // vectors from V[e[0]] to V[e[1]]

    for (int iE = 0; iE < E.rows(); iE++) {
      FEdge[iE] = (L[iE] - L0[iE]) * K[iE];   // contraction force is positive

      Force.row(E(iE, 0)) += Vec01.row(iE) / L[iE] * FEdge[iE];
      Force.row(E(iE, 1)) -= Vec01.row(iE) / L[iE] * FEdge[iE];
    }

    Force(all, 2).array() -= gravity;

    // contact with ground
    for (int iV = 0; iV < V.rows(); iV++) {

      // support and friction
      if (V(iV, 2) < 0 and Force(iV, 2) < 0) {
        double forceSupport = -Force(iV, 2);
        Force(iV, 2) = 0;

        double fFrictionMaxMag = forceSupport * friction;
        VectorXd velHorizontal(3);
        velHorizontal << Vel(iV, 0), Vel(iV, 1), 0;

        if (fFrictionMaxMag * h > velHorizontal.norm()) {
          fFrictionMaxMag = velHorizontal.norm() / h;
        }

        Force.row(iV) += -fFrictionMaxMag * velHorizontal / velHorizontal.norm();
      }

      // velocity on ground
      if (V(iV, 2) < 0 and Vel(iV, 2) < 0) {
        Vel(iV, 2) = 0;
        V(iV, 2) = 0;
      }
    }

    Vel = Vel + Force * h;
    Vel = Vel * damping;

    V += Vel * h;

  }

  return V;
}


// PYBIND11_MODULE(model, m) {
//   // Add numpy initialization AND proper error handling
//   try {
//       py::module::import("numpy");
      
//       py::class_<Model>(m, "Model")
//       .def(py::init([](py::array_t<double> k, double h, double gravity, double damping, double friction, 
//         py::array_t<double> v0, py::array_t<int> e, double contraction_speed, py::array_t<int> fixed) {
//           auto k_buf = k.request();
//           auto v0_buf = v0.request();
//           auto e_buf = e.request();
//           auto fixed_buf = fixed.request();

//           return new Model(
//           Eigen::Map<Eigen::VectorXd>((double*)k_buf.ptr, k_buf.shape[0]),
//           h,
//           gravity, 
//           damping,
//           friction,
//           Eigen::Map<Eigen::MatrixXd>((double*)v0_buf.ptr, v0_buf.shape[0], v0_buf.shape[1]),
//           Eigen::Map<Eigen::MatrixXi>((int*)e_buf.ptr, e_buf.shape[0], e_buf.shape[1]),
//           contraction_speed,
//           Eigen::Map<Eigen::VectorXi>((int*)fixed_buf.ptr, fixed_buf.shape[0])
//           );
//           }))
    
//       .def("getL", [](Model& self, py::array_t<double> V, py::array_t<int> E) {
//         auto V_buf = V.request();
//         auto E_buf = E.request();
//         Eigen::MatrixXd V_eigen = Eigen::Map<Eigen::MatrixXd>((double*)V_buf.ptr, V_buf.shape[0], V_buf.shape[1]);
//         Eigen::MatrixXi E_eigen = Eigen::Map<Eigen::MatrixXi>((int*)E_buf.ptr, E_buf.shape[0], E_buf.shape[1]);
//         return self.getL(V_eigen, E_eigen);
//       })
//       .def("getE", &Model::getE)

//       .def("step", [](Model& self, py::array_t<double> times, py::array_t<double> lengths, int numSteps) {
//         auto times_buf = times.request();
//         auto lengths_buf = lengths.request();
        
//         auto result = self.step(
//             Eigen::Map<Eigen::VectorXd>((double*)times_buf.ptr, times_buf.shape[0]),
//             Eigen::Map<Eigen::MatrixXd>((double*)lengths_buf.ptr, lengths_buf.shape[0], lengths_buf.shape[1]),
//             numSteps
//         );
        
//         return py::make_tuple(result.first, result.second);
//       })

//       .def("stepForGym", [](Model& self, py::array_t<double> lengths, int numSteps) {
//         auto lengths_buf = lengths.request();
//         return self.stepForGym(
//             Eigen::Map<Eigen::VectorXd>((double*)lengths_buf.ptr, lengths_buf.shape[0]),
//             numSteps
//         );
//       })
//       ;

//   } catch (const std::exception& e) {
//       std::cerr << "Error: " << e.what() << std::endl;
//       throw;
//   }
// }


PYBIND11_MODULE(model, m) {
  try {
    py::module::import("numpy");
    
    py::class_<Model>(m, "Model")
      .def(py::init([](py::array_t<double> k, double h, double gravity, double damping, double friction,
                      py::array_t<double> v0, py::array_t<int> e, double contraction_speed,
                      py::array_t<int> fixed) {
          // Get buffer info
          py::buffer_info k_buf = k.request();
          py::buffer_info v0_buf = v0.request();
          py::buffer_info e_buf = e.request();
          py::buffer_info fixed_buf = fixed.request();
          
          // Validate dimensions
          if(v0_buf.ndim != 2 || v0_buf.shape[1] != 3) 
              throw std::runtime_error("v0 must be a 2D array with 3 columns");
          if(e_buf.ndim != 2 || e_buf.shape[1] != 2) 
              throw std::runtime_error("e must be a 2D array with 2 columns");
          if(k_buf.ndim != 1 || k_buf.shape[0] != e_buf.shape[0])
              throw std::runtime_error("k must be a 1D array with length equal to number of edges");
          
          // Explicit mapping for k (stiffness)
          Eigen::VectorXd k_vec(k_buf.shape[0]);
          const double* k_ptr = static_cast<double*>(k_buf.ptr);
          for(size_t i = 0; i < k_buf.shape[0]; i++) {
              k_vec(i) = k_ptr[i];
          }
          
          // Explicit mapping for vertices
          Eigen::MatrixXd v0_mat(v0_buf.shape[0], 3);
          const double* v0_ptr = static_cast<double*>(v0_buf.ptr);
          for(size_t i = 0; i < v0_buf.shape[0]; i++) {
              for(size_t j = 0; j < 3; j++) {
                  v0_mat(i,j) = v0_ptr[i * 3 + j];
              }
          }
          
          // Explicit mapping for edges
          Eigen::MatrixXi e_mat(e_buf.shape[0], 2);
          const int* e_ptr = static_cast<int*>(e_buf.ptr);
          for(size_t i = 0; i < e_buf.shape[0]; i++) {
              for(size_t j = 0; j < 2; j++) {
                  e_mat(i,j) = e_ptr[i * 2 + j];
              }
          }
          
          // Explicit mapping for fixed vertices
          Eigen::VectorXi fixed_vec(fixed_buf.shape[0]);
          const int* fixed_ptr = static_cast<int*>(fixed_buf.ptr);
          for(size_t i = 0; i < fixed_buf.shape[0]; i++) {
              fixed_vec(i) = fixed_ptr[i];
          }

          return new Model(
              k_vec,
              h, gravity, damping, friction,
              v0_mat,
              e_mat,
              contraction_speed,
              fixed_vec
          );
      }))
      .def("getL", [](Model& self, py::array_t<double> V, py::array_t<int> E) {
          py::buffer_info V_buf = V.request();
          py::buffer_info E_buf = E.request();
          
          if(V_buf.ndim != 2 || V_buf.shape[1] != 3)
              throw std::runtime_error("V must be a 2D array with 3 columns");
          if(E_buf.ndim != 2 || E_buf.shape[1] != 2)
              throw std::runtime_error("E must be a 2D array with 2 columns");
          
          Eigen::MatrixXd V_mat(V_buf.shape[0], 3);
          const double* V_ptr = static_cast<double*>(V_buf.ptr);
          for(size_t i = 0; i < V_buf.shape[0]; i++) {
              for(size_t j = 0; j < 3; j++) {
                  V_mat(i,j) = V_ptr[i * 3 + j];
              }
          }
          
          Eigen::MatrixXi E_mat(E_buf.shape[0], 2);
          const int* E_ptr = static_cast<int*>(E_buf.ptr);
          for(size_t i = 0; i < E_buf.shape[0]; i++) {
              for(size_t j = 0; j < 2; j++) {
                  E_mat(i,j) = E_ptr[i * 2 + j];
              }
          }
          
          return self.getL(V_mat, E_mat);
      })
      .def("getE", &Model::getE)
      .def("step", [](Model& self, py::array_t<double> times, py::array_t<double> lengths, int numSteps) {
          py::buffer_info times_buf = times.request();
          py::buffer_info lengths_buf = lengths.request();
          
          if(lengths_buf.ndim != 2)
              throw std::runtime_error("lengths must be a 2D array");
          
          Eigen::VectorXd times_vec(times_buf.shape[0]);
          const double* times_ptr = static_cast<double*>(times_buf.ptr);
          for(size_t i = 0; i < times_buf.shape[0]; i++) {
              times_vec(i) = times_ptr[i];
          }
          
          Eigen::MatrixXd lengths_mat(lengths_buf.shape[0], lengths_buf.shape[1]);
          const double* lengths_ptr = static_cast<double*>(lengths_buf.ptr);
          for(size_t i = 0; i < lengths_buf.shape[0]; i++) {
              for(size_t j = 0; j < lengths_buf.shape[1]; j++) {
                  lengths_mat(i,j) = lengths_ptr[i * lengths_buf.shape[1] + j];
              }
          }
          
          auto result = self.step(times_vec, lengths_mat, numSteps);
          return py::make_tuple(result.first, result.second);
      })
      .def("stepForGym", [](Model& self, py::array_t<double> lengths, int numSteps) {
          py::buffer_info lengths_buf = lengths.request();
          
          Eigen::VectorXd lengths_vec(lengths_buf.shape[0]);
          const double* lengths_ptr = static_cast<double*>(lengths_buf.ptr);
          for(size_t i = 0; i < lengths_buf.shape[0]; i++) {
              lengths_vec(i) = lengths_ptr[i];
          }
          
          return self.stepForGym(lengths_vec, numSteps);
      });

  } catch (const std::exception& e) {
      std::cerr << "Error in pybind11 module: " << e.what() << std::endl;
      throw;
  }
}