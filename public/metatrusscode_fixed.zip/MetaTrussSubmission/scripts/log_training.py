import os
import numpy as np
import sys
import time

script_dir = os.path.dirname(__file__)
root_dir = os.path.dirname(script_dir)
sys.path.append(root_dir)


from pyPneuMesh.utils import readNpy, readMooDict
from pyPneuMesh.GA import GA

gacheckpoint_dir = sys.argv[1]
ga = GA(GACheckpointDir=gacheckpoint_dir)
ga.logPool(ga.elitePool, printing=True, showAllGenes=True, showRValue=True)


