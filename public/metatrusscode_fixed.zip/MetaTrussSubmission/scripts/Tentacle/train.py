import numpy as np
import json
import multiprocessing


import os
import sys

# Get the directory of the script
script_dir = os.path.dirname(__file__)

grand_grand_parent_dir = os.path.dirname(os.path.dirname(script_dir))

sys.path.append(grand_grand_parent_dir)

from pyPneuMesh.utils import readNpy, readMooDict
from pyPneuMesh.Model import Model
from pyPneuMesh.Graph import Graph
from pyPneuMesh.MOO import MOO
from pyPneuMesh.GA import GA

GASetting = {
    'nGenesPerPool': 512,
    'nSurvivedMin': 128,  # actually is max
    'nGensPerPool': 6,
    
    'nWorkers': multiprocessing.cpu_count(),
    
    'folderDir': 'scripts/Tentacle',
    
    'graphRandomInit': True,
    'contractionActionRandomInit': True,
    
    'contractionMutationChance': 0.1,
    'actionMutationChance': 0.1,
    'graphMutationChance': 0.8,
    
    'contractionCrossChance': 0.08,
    'actionCrossChance': 0.08,
    'crossChance': 0.4,
}

ga = GA(GASetting=GASetting)
ga.run()
