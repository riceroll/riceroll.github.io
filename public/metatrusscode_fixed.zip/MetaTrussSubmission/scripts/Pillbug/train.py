import numpy as np
import json
import multiprocessing

import os
import sys
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(script_dir, '../..'))


from pyPneuMesh.utils import readNpy, readMooDict
from pyPneuMesh.Model import Model
from pyPneuMesh.Graph import Graph
from pyPneuMesh.MOO import MOO
from pyPneuMesh.GA import GA


GASetting = {
    'nGenesPerPool': 128,
    'nSurvivedMin': 32,  # actually is max
    'nGensPerPool': 4,
    
    'nWorkers': multiprocessing.cpu_count(),
    
    'folderDir': 'scripts/Pillbug',
    
    'graphRandomInit': True,
    'contractionActionRandomInit': True,
    
    'contractionMutationChance': 0.1,
    'actionMutationChance': 0.1,
    'graphMutationChance': 0.8,
    
    'contractionCrossChance': 0.08,
    'actionCrossChance': 0.08,
    'crossChance': 0.4,
}

ga = GA(GASetting=GASetting)
ga.run()


