import numpy as np
import json
import multiprocessing


import os
import sys
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(script_dir, '../..'))

from pyPneuMesh.utils import readNpy, readMooDict
from pyPneuMesh.Model import Model
from pyPneuMesh.Graph import Graph
from pyPneuMesh.MOO import MOO
from pyPneuMesh.GA import GA

GASetting = {
    'nGenesPerPool': 512,
    'nSurvivedMin': 128,     # actually is max
    'nGensPerPool': 6,
    
    'nWorkers': multiprocessing.cpu_count(),
    
    'folderDir': 'scripts/Quadruped/',

    'graphRandomInit': True,
    'contractionActionRandomInit': True,

    'contractionMutationChance': 0.01,
    'actionMutationChance': 0.01,
    'graphMutationChance': 0.1,
    'contractionCrossChance': 0.02,
    'actionCrossChance': 0.02,
    'crossChance': 0.5,
}
ga = GA(GASetting=GASetting)
ga.run()
