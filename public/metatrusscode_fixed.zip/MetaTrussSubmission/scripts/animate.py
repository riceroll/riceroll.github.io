import os
import numpy as np
import sys
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Line3DCollection
import matplotlib.animation as animation
import matplotlib.colors as mcolors
import time

script_dir = os.path.dirname(__file__)
grand_grand_parent_dir = os.path.dirname(os.path.dirname(script_dir))
sys.path.append(grand_grand_parent_dir)

name = sys.argv[1].capitalize()
fileDir = os.path.join('./scripts/{}/'.format(name), '{}.simulation.npy'.format(name))
data = np.load(fileDir, allow_pickle=True).all()

speed = float(sys.argv[2]) if len(sys.argv) > 2 else 1.0

e = data['e']
edgeChannel = data['edgeChannel']
VTrajectories = data['VTrajectories']

# Calculate the bounds for the entire trajectory
def get_trajectory_bounds(Vs):
    # Flatten the vertices array to find overall min and max
    all_vertices = Vs.reshape(-1, 3)
    
    # Get min and max for each dimension
    mins = np.min(all_vertices, axis=0)
    maxs = np.max(all_vertices, axis=0)
    
    # Add some padding (10% of the range)
    padding = (maxs - mins) * 0.1
    
    return mins - padding, maxs + padding

for Vs in VTrajectories:
    # Get the bounds once before starting the animation
    mins, maxs = get_trajectory_bounds(Vs)
    
    fig = plt.figure(figsize=(20, 8))
    ax = fig.add_subplot(111, projection='3d', computed_zorder=True)
    
    plt.subplots_adjust(left=0.01, right=0.99, bottom=0.01, top=0.99, wspace=0.1, hspace=0.1)
    
    ax.w_xaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
    ax.w_yaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
    
    # turn off z-axis
    ax.set_zticks([])
    ax.set_zlabel('')
    ax.set_zticklabels([])
    
    # Define a list of colors
    color_list = ['#F21365', '#66C8D2', '#F2B807', '#63A5BF', '#F5AB55', '#F27A5E']

    color_list2 = ['#FFFFFF', '#FFFFFF', '#FFFFFF', '#FFFFFF', '#FFFFFF', '#FFFFFF']
    
    start_time = time.time()
    
    # Set the camera position and orientation
    elevation = 30  # Elevation angle in degrees
    azimuth = -60   # Azimuth angle in degrees
    ax.view_init(elev=elevation, azim=azimuth)


    max_range = np.max(maxs - mins)
    mid_x = (maxs[0] + mins[0]) * 0.5
    mid_y = (maxs[1] + mins[1]) * 0.5
    mid_z = (maxs[2] + mins[2]) * 0.5
    
    ax.set_xlim(mid_x - max_range * 0.5, mid_x + max_range * 0.5)
    ax.set_ylim(mid_y - max_range * 0.5, mid_y + max_range * 0.5)
    ax.set_zlim(mid_z - max_range * 0.5, mid_z + max_range * 0.5)

    def update(frame):

        elev = ax.elev
        azim = ax.azim
        xlim = ax.get_xlim()
        ylim = ax.get_ylim()
        zlim = ax.get_zlim()
        
        ax.clear()
    
        elapsed_time = time.time() - start_time
        fps = 1000 * speed  # Frames per second
        current_frame = int(elapsed_time * fps) % len(Vs)

        fig.patch.set_facecolor('white')  # Set figure background
        ax.set_facecolor('white')  # Set axes background

        # Hide grid and ticks
        ax.grid(False)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_zticks([])

        # Make axis panes black
        ax.w_xaxis.set_pane_color((1, 1, 1, 1.0))
        ax.w_yaxis.set_pane_color((1, 1, 1, 1.0))
        ax.w_zaxis.set_pane_color((1, 1, 1, 1.0))

        ax.set_axis_off()
        
        # Make axis lines and labels white
        ax.xaxis.label.set_color('white')
        ax.yaxis.label.set_color('white')
        ax.tick_params(colors='white')
        
        V = Vs[current_frame]
        lines = []
        colors = []
        
        for i in range(len(e)):
            start = tuple(V[e[i, 0]])
            end = tuple(V[e[i, 1]])
            lines.append([start, end])
            color_index = edgeChannel[i]
            # Make colors more vibrant with alpha
            base_color = mcolors.to_rgba(color_list[color_index], alpha=0.8)
            colors.append(base_color)

        # Optional: Add simple shadow by projecting lines onto xy-plane
        shadow_z = mins[2]  # Project at bottom
        shadow_lines = [[(*start[:2], shadow_z), (*end[:2], shadow_z)] for start, end in lines]
        shadow_collection = Line3DCollection(shadow_lines, colors='gray', alpha=0.1, linewidths=3)
        ax.add_collection(shadow_collection)

        # optional: Add a grid
        grid_size = max_range * 2  # Use the same max_range we calculated for bounds
        grid_spacing = 0.3
        z_pos = mins[2]  # Position at the bottom
        # Create grid lines
        for x in np.arange(-grid_size/2, grid_size/2 + grid_spacing, grid_spacing):
            ax.plot([x, x], [-grid_size/2, grid_size/2], [z_pos, z_pos], color='gray', alpha=0.2, linewidth=0.5)
            ax.plot([-grid_size/2, grid_size/2], [x, x], [z_pos, z_pos], color='gray', alpha=0.2, linewidth=0.5)
    
        # Add the lines to the plot
        line_segments = Line3DCollection(lines, colors=colors, linewidths=3)
        line_segments.set_sort_zpos(None)  # Enable depth sorting
        ax.add_collection(line_segments)

        ax.set_xlim(xlim)
        ax.set_ylim(ylim)
        ax.set_zlim(zlim)

        ax.view_init(elev=elev, azim=azim)
        
        ax.set_box_aspect((1, 1, 1))  # Changed from (1, 1, 0.5) to (1, 1, 1)
        ax.grid(False)
    
    # Create the animation
    ani = animation.FuncAnimation(fig, update, frames=len(Vs), interval=1)
    
    # Display the animation
    plt.show()