import numpy as np
import json
import multiprocessing

import os
import sys
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(script_dir, '..'))

from pyPneuMesh.utils import readNpy, readMooDict
from pyPneuMesh.Model import Model
from pyPneuMesh.Graph import Graph
from pyPneuMesh.MOO import MOO
from pyPneuMesh.GA import GA

from pyPneuMesh.utils import readNpy, readMooDict
from pyPneuMesh.GA import GA

gacheckpoint_dir = sys.argv[1]

moo_index = int(sys.argv[2]) if len(sys.argv) > 2 else 0

# parent parent directory folder name
dirname = os.path.dirname(os.path.dirname(os.path.dirname(gacheckpoint_dir)))

name = os.path.basename(dirname)

print('loading {} checkpoint from {}'.format(name, gacheckpoint_dir))

ga = GA(GACheckpointDir=gacheckpoint_dir)

moo = ga.elitePool[moo_index]['moo']


# collect the simulation data
data = {
    'e': moo.model.e,
    'edgeChannel': moo.model.edgeChannel,
    'VTrajectories': [],
}

numActions = len(moo.multiMotion.actionSeqs)
for iAction in range(numActions):
    Vs, Fs = moo.multiMotion.simulate(iAction, numLoop=4)
    data['VTrajectories'].append(Vs)

simulationDir = os.path.join('./scripts/{}/'.format(name), '{}.simulation.npy'.format(name))


np.save(simulationDir, data)
print('saved as {}'.format(simulationDir))











