# MetaTruss

## 1. Build

1. **Install Docker**  
   Follow the instructions on [Docker's installation page](https://docs.docker.com/engine/install/).

2. **Build the Image**  
   From the project root, run:
   ```bash
   docker build -t metatruss . --cache-from metatruss:latest
   ```

## 2. Simulate Pretrained Designs

Pretrained design parameters are stored in `./scripts/[metatruss name]/data/`. Follow these steps to simulate and visualize them.

### 2.1 Generate Simulation

Run this command to generate the simulation trajectory:
```bash
docker run -it -v $(pwd)/scripts/:/home/scripts/ metatruss python scripts/simulate_pretrained.py [metatruss name]
```

Replace `[metatruss name]` with one of: `helmet`, `lobster`, `pillbug`, `tentacle`, or `quadruped`.

The simulation will be saved to:  
`./scripts/[metatruss name]/[metatruss name].simulation.npy`

### 2.2 Visualize Simulation

Since GUI applications cannot run in Docker, you'll need to save the simulation trajectory first, then visualize it locally using matplotlib.

1. **Set Up Local Environment**
   ```bash
   pip install numpy matplotlib
   ```

2. **Run Visualization**
   ```bash
   python scripts/animate.py [metatruss name] [speed]
   ```
   Replace `[metatruss name]` with your metatruss name. `[speed]` is optional and defaults to 1.0 (adjust to speed up or slow down)

    **Controls:**
    - Zoom: Right-click and drag
    - Rotate: Left-click and drag
    - The next simulation showing the next action sequences will automatically start after closing the current window.

## 3. Train and Simulate Designs

### 3.1 Training

Start training with:
```bash
docker run -it -v $(pwd)/scripts/:/home/scripts/ metatruss python scripts/[metatruss name]/train.py
```

Replace `[metatruss name]` with the metatruss you want to train (`helmet`, `lobster`, `pillbug`, `tentacle`, `quadruped`, or `quadruped_[2/8/16/32/64]`).

**Notes**
- Experiments are parallelized by default (optimized for 64-core machines)
- Checkpoint files are saved to: `./scripts/[metatruss name]/output/[date and time]/`
- Training logs are saved to: `./scripts/[metatruss name]/output/[date and time]/log.txt`
  - Includes multi-objective performance (fitness) of elite designs by generation

### 3.2 Check Multi-objective Performance (Optional)

Review the performance of your training process:
```bash
docker run -it -v $(pwd)/scripts/:/home/scripts/ metatruss python scripts/log_training.py [checkpoint path]
```

Replace `[checkpoint path]` with your checkpoint file directory relative to the root folder. 
  - Example: `scripts/Helmet/output/2023-10-01_12-00-00/checkpoint_1000.pth`

This will display all elite designs and their sub-objective scores. Note the index of your preferred design for simulation. Please check the paper for definitions of the sub-objectives.

### 3.3 Generate Training Simulation

Generate simulation from training results:
```bash
docker run -it -v $(pwd)/scripts/:/home/scripts/ metatruss python scripts/simulate_training.py [checkpoint path] [design index]
```

Replace `[checkpoint path]` with your checkpoint file directory relative to the root folder
  - Example: `scripts/Helmet/output/2023-10-01_12-00-00/checkpoint_1000.pth`

Replace `[design index]` with your chosen design number (defaults to 0)

The simulation will be saved to:  `./scripts/[metatruss name]/[metatruss name].simulation.npy`

### 3.4 Visualize Training Results

Follow the same visualization process described in section 2.2.